package com.example.supportticketsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.supportticketsystem.entity.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

}