package com.example.supportticketsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(
            @RequestParam String username,
            @RequestParam String password,
            Model model) {

        if (username.equals("admin") && password.equals("admin")) {
            return "redirect:/ticket/all";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }
}