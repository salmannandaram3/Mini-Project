package com.example.supportticketsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @GetMapping("/user/login")
    public String userLogin() {
        return "user-login";
    }

    @PostMapping("/user/login")
    public String validateUser(
            @RequestParam String username,
            @RequestParam String password) {

        if (username.equals("user") &&
            password.equals("user123")) {

            return "redirect:/ticket/new";
        }

        return "redirect:/user/login";
    }
}