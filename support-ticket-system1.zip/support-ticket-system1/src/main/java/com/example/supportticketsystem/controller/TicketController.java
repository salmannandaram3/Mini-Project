
package com.example.supportticketsystem.controller;

import com.example.supportticketsystem.entity.Ticket;
import com.example.supportticketsystem.repository.TicketRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/ticket")
public class TicketController {

    @Autowired
    private TicketRepository ticketRepository;

    // Show Create Ticket Form
    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("ticket", new Ticket());
        return "ticket-form";
    }

    // Save Ticket
    @PostMapping("/save")
    public String saveTicket(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String subject,
            @RequestParam String description,
            @RequestParam String priority) {

        Ticket ticket = new Ticket();

        ticket.setName(name);
        ticket.setEmail(email);
        ticket.setSubject(subject);
        ticket.setDescription(description);
        ticket.setPriority(priority);
        ticket.setStatus("OPEN");
        ticket.setCreatedDate(java.time.LocalDate.now().toString());
        ticketRepository.save(ticket);

        return "redirect:/ticket/all";
    }

    // View All Tickets + Dashboard
    @GetMapping("/all")
    public String viewTickets(Model model) {

        List<Ticket> tickets = ticketRepository.findAll();

        long openCount = tickets.stream()
                .filter(t -> "OPEN".equalsIgnoreCase(t.getStatus()))
                .count();

        long closedCount = tickets.stream()
                .filter(t -> "CLOSED".equalsIgnoreCase(t.getStatus()))
                .count();

        long highPriorityCount = tickets.stream()
                .filter(t -> "HIGH".equalsIgnoreCase(t.getPriority()))
                .count();

        model.addAttribute("tickets", tickets);
        model.addAttribute("ticketCount", tickets.size());

        model.addAttribute("openCount", openCount);
        model.addAttribute("closedCount", closedCount);
        model.addAttribute("highPriorityCount", highPriorityCount);

        return "ticket-list";
    }

    // Filter Tickets
    @GetMapping("/filter")
    public String filterTickets(
            @RequestParam String status,
            Model model) {

        List<Ticket> tickets;

        if ("ALL".equalsIgnoreCase(status)) {
            tickets = ticketRepository.findAll();
        } else {
            tickets = ticketRepository.findAll()
                    .stream()
                    .filter(t -> status.equalsIgnoreCase(t.getStatus()))
                    .collect(Collectors.toList());
        }

        model.addAttribute("tickets", tickets);
        model.addAttribute("ticketCount", tickets.size());

        return "ticket-list";
    }

    // Delete Ticket
    @GetMapping("/delete/{id}")
    public String deleteTicket(@PathVariable Long id) {

        ticketRepository.deleteById(id);

        return "redirect:/ticket/all";
    }

    // Open Solution Form
    @GetMapping("/solution/{id}")
    public String showSolutionForm(
            @PathVariable Long id,
            Model model) {

        Ticket ticket = ticketRepository.findById(id).orElse(null);

        model.addAttribute("ticket", ticket);

        return "solution-form";
    }

    // Save Solution and Close Ticket
    @PostMapping("/save-solution")
    public String saveSolution(
            @RequestParam Long id,
            @RequestParam String solution) {

        ticketRepository.findById(id).ifPresent(ticket -> {

            ticket.setSolution(solution);
            ticket.setStatus("CLOSED");

            ticketRepository.save(ticket);
        });

        return "redirect:/ticket/all";
    }
}

