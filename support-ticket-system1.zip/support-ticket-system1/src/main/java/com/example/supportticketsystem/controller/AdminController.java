package com.example.supportticketsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController {

    @GetMapping("/admin/login")
    public String adminLogin() {
        return "admin-login";
    }

    @PostMapping("/admin/login")
    public String validateAdmin(
            @RequestParam String username,
            @RequestParam String password) {

        if (username.equals("admin") &&
            password.equals("admin123")) {

            return "redirect:/ticket/all";
        }

        return "redirect:/admin/login";
    }
}